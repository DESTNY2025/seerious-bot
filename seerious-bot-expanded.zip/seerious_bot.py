import logging
from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes, ConversationHandler
from bot_config import TOKEN
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

NAME, BIRTHDATE, BIRTHPLACE = range(3)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("👋 Привет! Я Seerious — твой прорицатель.

Для начала предсказания, как тебя зовут?")
    return NAME

async def get_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['name'] = update.message.text
    await update.message.reply_text("📅 Введи свою дату рождения в формате ДД.ММ.ГГГГ:")
    return BIRTHDATE

async def get_birthdate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['birthdate'] = update.message.text
    await update.message.reply_text("🌍 Введи место рождения:")
    return BIRTHPLACE

async def get_birthplace(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['birthplace'] = update.message.text
    prediction = generate_prediction(context.user_data)
    await update.message.reply_text(prediction)
    return ConversationHandler.END

def generate_prediction(data):
    name = data['name']
    birthdate = data['birthdate']
    birthplace = data['birthplace']
    date = datetime.now().strftime('%d.%m.%Y')
    return f"""📜 Пророчество на {date} для {name}:

💘 Любовь: сегодня ты можешь почувствовать тягу к душевной близости.
💸 Деньги: возможны неожиданные возможности — будь внимателен.
💼 Бизнес: день благоприятен для нестандартных решений.
🔥 Энергия: энергия будет нестабильной, чередуй работу и отдых.
⚠️ Опасности: избегай конфликтов и не спеши принимать решения.

🔮 (Дата рождения: {birthdate}, Место: {birthplace})
"""

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Предсказание отменено. Обратись ко мне, когда будешь готов 🙏")
    return ConversationHandler.END

def main():
    app = ApplicationBuilder().token(TOKEN).build()

    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("start", start)],
        states={
            NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_name)],
            BIRTHDATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_birthdate)],
            BIRTHPLACE: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_birthplace)],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
    )

    app.add_handler(conv_handler)
    app.run_polling()

if __name__ == '__main__':
    main()
