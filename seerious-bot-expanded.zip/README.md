# Seerious Telegram Bot

Бот Seerious выдаёт бесплатное мистическое предсказание на 5 тем, используя имя, дату и место рождения пользователя.

## Возможности
- 1 бесплатное предсказание (5 тем, на 1 день)
- Платные предсказания (20 тем, на неделю или месяц)
- Оплата: USDT, TON, Telegram Stars, DESTNYcoin

## Установка

1. Установите зависимости:
```bash
pip install -r requirements.txt
```

2. В `bot_config.py` вставьте токен от @BotFather

3. Запустите бота:
```bash
python seerious_bot.py
```

## Автоматический деплой
Можно использовать Render или Replit. Поддерживается Procfile и start.sh.
