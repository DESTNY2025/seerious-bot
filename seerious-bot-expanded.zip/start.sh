#!/bin/bash
pip install -r requirements.txt
python3 seerious_bot.py
